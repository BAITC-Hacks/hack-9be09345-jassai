"""Developer entrypoint; end-user launcher is maintained by teammate B."""
import argparse
import getpass
import json
import os
from pathlib import Path
import sys
import warnings

from app.auth import initialize_bootstrap
from app.config import Settings
from app.db import Database, revision
from app.imports import apply_validated, validate_files


def configure_session_ai(model=None):
    """Accept a key only through hidden local input, never argv or a file."""
    if not sys.stdin.isatty():
        raise ValueError("Для скрытого ввода откройте обычный интерактивный терминал.")
    if model is not None and not model.strip():
        raise ValueError("Идентификатор модели не должен быть пустым.")
    # getpass may otherwise fall back to echoed input when /dev/tty cannot be
    # controlled. Abort instead of ever accepting an unmasked credential.
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        try:
            key = getpass.getpass("Новый OpenAI API-ключ (ввод скрыт): ").strip()
        except (getpass.GetPassWarning, EOFError) as exc:
            raise ValueError("Скрытый ввод недоступен. Ключ не сохранён; используйте интерактивный терминал.") from exc
    if not key or any(character.isspace() for character in key):
        raise ValueError("Ключ не введён или содержит пробельные символы. Сервер не запущен.")
    os.environ["OPENAI_API_KEY"] = key
    os.environ["CAREERQUEST_RECOMMENDER"] = "app.ai.provider:recommend"
    if model is not None:
        os.environ["OPENAI_MODEL"] = model.strip()
    print("AI-модуль включён для этого запуска. Ключ не записан в файл; доступ к API ещё не проверен.")


def main():
    parser = argparse.ArgumentParser(description="Career Quest backend")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("init", help="Initialize database and one-time bootstrap token")
    serve = commands.add_parser("serve", help="Run the local HTTP server")
    serve.add_argument("--port", type=int, default=8000)
    serve.add_argument("--ask-ai-key", action="store_true", help="Read an OpenAI key using hidden terminal input; keep it only for this process")
    serve.add_argument("--model", help="Model ID for --ask-ai-key (otherwise OPENAI_MODEL or the provider default)")
    importer = commands.add_parser("import", help="Validate and import an organizer dataset locally")
    importer.add_argument("dataset", type=Path)
    importer.add_argument("--mode", choices=["add", "update"], default="add")
    args = parser.parse_args()
    if args.command == "serve":
        if args.model is not None and not args.ask_ai_key:
            parser.error("--model requires --ask-ai-key; alternatively set OPENAI_MODEL in the environment.")
        if args.ask_ai_key:
            try:
                configure_session_ai(args.model)
            except ValueError as exc:
                parser.error(str(exc))
            except KeyboardInterrupt:
                print("\nПодключение отменено. Сервер не запущен.", file=sys.stderr)
                raise SystemExit(130)
        import uvicorn
        uvicorn.run("app.main:app", host="127.0.0.1", port=args.port)
        return
    settings = Settings.from_env()
    db = Database(settings.data_dir / "careerquest.sqlite3")
    db.initialize()
    initialize_bootstrap(db, settings)
    if args.command == "init":
        print(json.dumps({"data_dir": str(settings.data_dir), "bootstrap_token_file": str(settings.data_dir / "setup-token.txt") if not settings.bootstrap_token else None}, ensure_ascii=False))
        return
    names = ["employees.json", "events.json", "skills.json", "activity_history.csv"]
    files = {name: (args.dataset / name).read_bytes() for name in names if (args.dataset / name).is_file()}
    with db.connection(write=True) as conn:
        report, payload = validate_files(conn, files, args.mode)
        if report["valid"]:
            apply_validated(conn, payload, report["as_of_date"])
            report["data_revision"] = revision(conn)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report["valid"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
