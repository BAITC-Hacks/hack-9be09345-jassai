import {escapeHtml as e} from './ui.js';
import {icon} from './icons.js';

export const chatPrompts=[
  {label:'Мой следующий шаг',text:'С чего мне начать, чтобы приблизиться к моей карьерной цели?'},
  {label:'Приоритетные навыки',text:'Какие навыки мне сейчас важнее развивать и почему?'},
  {label:'План обучения',text:'Помоги составить реалистичный план развития по доступным мне активностям.'},
];

export const emptyChat=()=>({messages:[],draft:'',pending:false,error:'',model:'',provider:''});

export function chatHomeCard(){
  return `<section class="chat-home-callout" aria-label="AI-помощник по развитию"><span class="chat-emblem">${icon('sparkles')}</span><div><span class="eyebrow">Личный AI-помощник</span><h2>Обсудим ваш следующий шаг?</h2><p>Задайте вопрос о цели, навыках или обучении — с учётом вашего профиля.</p></div><a class="button" href="#chat">Открыть AI-чат ${icon('arrow-right')}</a></section>`;
}

export function chatView(chat,{preview=false}={}){
  const disabled=chat.pending||preview;
  return `<div class="page-heading chat-heading"><div><h1>AI-чат</h1><p class="heading-sub">Разберём вашу цель и превратим вопросы в следующие шаги.</p></div><span class="pill neutral">${icon('lock')} Личное пространство</span></div>
  ${preview?'<div class="info"><span>Чат доступен после входа сотрудником в работающий сервер. В предпросмотре запросы не отправляются.</span></div>':''}
  <div class="chat-layout"><section class="chat-panel panel" aria-label="Разговор с AI-помощником">
    <div class="chat-toolbar"><div><span class="chat-status-dot" aria-hidden="true"></span><strong>Помощник по развитию</strong><span class="muted">OpenAI</span></div><button type="button" class="button text small" data-action="chat-clear" ${disabled||!chat.messages.length?'disabled':''}>Новый диалог</button></div>
    <div id="chat-messages" class="chat-messages" role="log" aria-label="Сообщения диалога" aria-live="polite" aria-relevant="additions text" aria-busy="${chat.pending}">
      ${chat.messages.length?chat.messages.map(message=>`<article class="chat-message ${message.role==='user'?'chat-message-user':'chat-message-assistant'}"><div class="chat-message-label">${message.role==='user'?'Вы':icon('sparkles')+' AI-помощник'}${message.status==='failed'?'<span>Ответ не получен</span>':''}</div><div class="chat-message-text">${e(message.content)}</div></article>`).join(''):`<div class="chat-welcome"><span class="chat-emblem">${icon('sparkles')}</span><h2>С чего начнём?</h2><p>Помогу разобраться в навыках, сравнить варианты обучения и наметить следующий шаг. Выберите вопрос или напишите свой.</p><div class="chat-prompts">${chatPrompts.map((prompt,index)=>`<button type="button" class="chat-prompt" data-action="chat-prompt" data-id="${index}" ${disabled?'disabled':''}>${e(prompt.label)} ${icon('arrow-right')}</button>`).join('')}</div></div>`}
      ${chat.pending?`<div class="chat-thinking" role="status">${icon('sparkles')}<span>Продумываю ответ с учётом вашего профиля…</span><span class="chat-thinking-dots" aria-hidden="true"><i></i><i></i><i></i></span></div>`:''}
    </div>
    ${chat.error?`<div class="chat-error" role="alert">${icon('alert-circle')}<div><strong>Не удалось получить ответ</strong><p>${e(chat.error)}</p><button type="button" class="button secondary small" data-action="chat-retry" ${disabled||!chat.draft.trim()?'disabled':''}>Повторить запрос</button></div></div>`:''}
    <form id="chat-form" class="chat-composer" aria-label="Написать AI-помощнику"><label for="chat-message">Ваш вопрос</label><textarea id="chat-message" name="message" rows="3" maxlength="2000" required placeholder="Например: как подготовиться к следующему грейду?" aria-describedby="chat-input-hint chat-privacy" ${preview?'disabled':chat.pending?'readonly':''}>${e(chat.draft)}</textarea><div class="chat-composer-footer"><span id="chat-input-hint" class="muted"><span class="chat-keyboard-hint">Enter — отправить · Shift+Enter — новая строка</span><span id="chat-character-count">${chat.draft.length} / 2000</span></span><button type="submit" class="button" ${disabled||!chat.draft.trim()?'disabled':''}>${chat.pending?'Ожидаем ответ…':'Отправить'} ${icon('arrow-right')}</button></div></form>
    <p id="chat-privacy" class="chat-privacy">${icon('lock')}<span>Вопрос, последние сообщения диалога и контекст вашего профиля отправляются в облачный OpenAI. Не вводите пароли, API-ключи или чужие персональные данные. Переписка хранится только в памяти этой вкладки и очищается при выходе или обновлении страницы.</span></p>
  </section><aside class="chat-context"><section class="panel"><span class="eyebrow">Контекст разговора</span><h2>Ваш путь, ваши вопросы</h2><ul><li>${icon('target')}<span><strong>Карьерная цель</strong><small>Текущая роль и направление развития</small></span></li><li>${icon('skills')}<span><strong>Навыки</strong><small>Пробелы и требования вашей цели</small></span></li><li>${icon('book')}<span><strong>Обучение</strong><small>Доступные вам активности</small></span></li></ul><p class="explanation">AI помогает обдумать варианты, но не изменяет данные и не принимает кадровые решения. Проверяйте важные выводы.</p><a class="button text small" href="#home">Мой путь ${icon('arrow-right')}</a></section>${chat.model?`<p class="chat-model muted">Ответы: ${e(chat.provider)} · ${e(chat.model)}</p>`:''}</aside></div>`;
}
